import findspark
findspark.init("/opt/cloudera/parcels/CDH-6.2.0-1.cdh6.2.0.p0.967373/lib/spark")
from pyspark.sql import SparkSession

from pyspark.sql.functions import explode,from_json,schema_of_json,lit
#Añade las importaciones que consideres necesarias


spark = SparkSession.builder.appName("STRUCTURED STREAMING").getOrCreate()

encabezados=['icao24','callsign','origin_country','time_position','last_contact','longitude','latitude','baro_altitude','on_ground','velocity','true_track','vertical_rate','sensors','geo_altitude','squawk','spi','position_source']

ejemplo='{"time":1621798530,"states":[["4b1814","SWR202V ","Switzerland",1621798528,1621798529,-3.35,42.2929,11590.02,false,240.05,65.03,0,null,11811,"5436",false,0],["3945f9","XK457QO ","France",1621798528,1621798529,8.326,41.9246,3787.14,false,151.83,139.67,-2.93,null,3992.88,"4717",false,0],["3442cb","ANE80NK ","Spain",1621798530,1621798530,-2.5402,37.9499,6713.22,false,155.1,42.58,0.33,null,6858,"5062",false,0],["47885f","BNOV    ","Norway",1621798241,1621798241,10.8363,63.4577,228.6,false,59.3,93.98,-2.28,null,312.42,"0247",false,0]]}'

flujo = #<FILL_IN> Conexión al Socket por el puerto asignado

#<FILL_IN> Procesado necesario para resolver los ejercicios

resultado= #<FILL_IN> Salida por Consola de la información procesada

resultado.awaitTermination()

