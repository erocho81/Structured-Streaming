import requests
import json
import time
import random
import socket
from requests.auth import HTTPBasicAuth


tiempo=0
contador=0

#Para más información sobre OpenSky consultar https://openskynetwork.github.io/opensky-api/

puerto=#se debe configurar con el número de puerto que tenéis asignado
#Para poder conectarse a OpenSky es necesario registrarse en https://opensky-network.org/ (botón verde arriba a la derecha)
nombre= '' # se debe poner el nombre con el que os registrasteis
password= '' # se debe poner la contraseña con la que os registrasteis

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
print("Esperando la conexión de Spark...")

s.bind(('localhost', puerto))
s.listen(1)
conn, addr = s.accept() 
print("Iniciando la conexión a OpenSky")

while (tiempo<60 and contador < 100):    
    inicio = time.time()
    respuesta=requests.get("https://opensky-network.org/api/states/all?lamin=35&lomin=-10&lamax=70&lomax=60",auth = HTTPBasicAuth(nombre, password))
    fin = time.time()
    tiempo=fin-inicio
    print(respuesta.text)
    datos=json.loads(respuesta.text)    
    vuelos=datos.get("states")
    n=len(vuelos)
    print()
    print(time.strftime('%H:%M:%S', time.localtime(datos.get("time"))),"Vuelos sobre Europa: ",n)
    conn.sendall((respuesta.text+"\n").encode('utf-8'))  
    contador+=1
    time.sleep(10) # espera de cortesía para no sobrecargar el servidor con peticiones

conn.close()