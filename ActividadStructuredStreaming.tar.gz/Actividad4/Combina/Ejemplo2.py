import findspark
findspark.init("/opt/cloudera/parcels/CDH-6.2.0-1.cdh6.2.0.p0.967373/lib/spark")
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("SparkStreaming").getOrCreate()

from pyspark.sql.functions import rand

spark.conf.set("spark.sql.shuffle.partitions", "1")

impresiones = (
  spark
    .readStream.format("rate").option("rowsPerSecond", "1").option("numPartitions", "1").load()
    .selectExpr("value AS idAnuncio", "timestamp AS tiempoImpresion")
)


resImpresiones=(impresiones
 .writeStream
    .outputMode("append")
    .format("console")
    .trigger(processingTime='3 seconds') 
    .start())

resImpresiones.awaitTermination()